package com.example.productmanagement;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.productmanagement.model.Product;
import com.example.productmanagement.service.ProductService;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@SpringBootApplication
public class ProductManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductManagementApplication.class, args);
    }

    @Bean
    CommandLineRunner init(ProductService productService) {
        return args -> {
            if (productService.listAll().isEmpty()) {
                productService.save(new Product(null, "Camiseta", "Camiseta 100% algodão", new BigDecimal("49.90"), 50, LocalDateTime.now()));
                productService.save(new Product(null, "Calça Jeans", "Calça jeans azul", new BigDecimal("129.90"), 20, LocalDateTime.now()));
                productService.save(new Product(null, "Tênis Esportivo", "Tênis para corrida", new BigDecimal("249.90"), 10, LocalDateTime.now()));
            }
        };
    }
}
