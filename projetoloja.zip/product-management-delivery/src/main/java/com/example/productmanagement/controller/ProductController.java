package com.example.productmanagement.controller;

import com.example.productmanagement.model.Product;
import com.example.productmanagement.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("products", productService.listAll());
        return "products/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("product", new Product());
        return "products/form";
    }

    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("product") Product product, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "products/form";
        }

        // Verifica se já existe produto com o mesmo nome (somente para novo cadastro)
        if (product.getId() == null && productService.existsByName(product.getName())) {
            model.addAttribute("error", "Já existe um produto com esse nome!");
            return "products/form";
        }

        productService.save(product);
        model.addAttribute("success", "Produto salvo com sucesso!");
        return "products/form"; // mantém no formulário mostrando a mensagem
    }

    @GetMapping("/edit/{id}")
    public String edit(@PathVariable Long id, Model model) {
        var opt = productService.getById(id);
        if (opt.isEmpty()) {
            return "redirect:/products";
        }
        model.addAttribute("product", opt.get());
        return "products/form";
    }

    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        productService.delete(id);
        return "redirect:/products";
    }
}
